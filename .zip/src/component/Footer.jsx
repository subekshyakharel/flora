import React from 'react'

function Footer() {
  return (
    <>
      <footer>
        <div className="foot">
         <p> ______________________________________________________________________________________________________________________________________________________________________________________________</p>
         <p><i class="fa fa-copyright" aria-hidden="true"></i>Copyright All rights reserved.</p>
        </div>
      </footer>
    </>
  )
}

export default Footer
