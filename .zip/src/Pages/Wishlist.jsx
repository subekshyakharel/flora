import React from 'react'
import wish from '../assets/img/wish.png'

function Wishlist() {
  return (
    <div className='wish'>
      <img src={wish} alt="" />
    </div>
  )
}

export default Wishlist
