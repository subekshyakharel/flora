var CatData = ["About", "Shop Now", "Contact us"]
export default CatData