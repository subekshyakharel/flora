import React from 'react'
import Header from './component/Header'
import Footer from './component/Footer'

function App() {
  return (
    <>
      <Header/>
      
    </>
  )
}

export default App
