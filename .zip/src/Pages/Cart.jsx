import React from 'react'
import cart from '../assets/img/cart.png'

function Cart() {
  return (
    <div className='cart'>
      <img className='cartimg' src={cart} alt="" />
    </div>
  )
}

export default Cart
